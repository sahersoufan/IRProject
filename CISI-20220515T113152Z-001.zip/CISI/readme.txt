CICI.ALL A file of 1,460 "documents" each with a unique ID (.I), title (.T), author (.A), abstract (.W) and list of cross-references to other documents (.X). 
CISI.QRY Original text of the query
CISI.REL relation giving query_id document_id 0 0 to indicate dument did is relevant to query qid
